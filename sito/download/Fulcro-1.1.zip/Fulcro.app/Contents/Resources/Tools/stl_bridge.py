#!/usr/bin/env python3
"""Genera STL binari parametrici per una Bambu A1 mini.

Nessuna libreria esterna: scrive direttamente il formato STL binario.
Ogni faccia e' un quad con vertici in ordine antiorario visto da fuori,
cosi le normali puntano tutte verso l'esterno e lo slicer non impazzisce.

  stl_bridge.py --forma scatola --larghezza 80 --profondita 60 --altezza 30 --spessore 2
  stl_bridge.py --forma cilindro --diametro 40 --altezza 25 --tubo
"""
import argparse
import math
import os
import struct
import sys

TRIANGLE = struct.Struct("<12fH")   # 12 float (normale + 3 vertici) + 2 byte di attributo = 50


class Mesh:
    def __init__(self):
        self.tris = []

    def quad(self, a, b, c, d):
        """Due triangoli dal quad a-b-c-d (antiorario visto da fuori)."""
        self.tri(a, b, c)
        self.tri(a, c, d)

    def tri(self, a, b, c):
        ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
        vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        n = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        self.tris.append(((nx / n, ny / n, nz / n), a, b, c))

    def fan(self, center, ring, up):
        n = len(ring)
        for i in range(n):
            if up:
                self.tri(center, ring[i], ring[(i + 1) % n])
            else:
                self.tri(center, ring[(i + 1) % n], ring[i])

    def write(self, path):
        with open(path, "wb") as f:
            f.write(b"Jarvis STL - " + os.path.basename(path).encode()[:60].ljust(67, b" "))
            f.write(struct.pack("<I", len(self.tris)))
            for (nx, ny, nz), a, b, c in self.tris:
                f.write(TRIANGLE.pack(nx, ny, nz,
                                      a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2], 0))
        return len(self.tris)


def scatola(m, W, D, H, t, cava):
    if not cava:
        m.quad((0, D, 0), (W, D, 0), (W, 0, 0), (0, 0, 0))          # sotto
        m.quad((0, 0, H), (W, 0, H), (W, D, H), (0, D, H))          # sopra
        m.quad((0, 0, 0), (W, 0, 0), (W, 0, H), (0, 0, H))          # davanti
        m.quad((W, D, 0), (0, D, 0), (0, D, H), (W, D, H))          # dietro
        m.quad((0, D, 0), (0, 0, 0), (0, 0, H), (0, D, H))          # sinistra
        m.quad((W, 0, 0), (W, D, 0), (W, D, H), (W, 0, H))          # destra
        return

    m.quad((0, 0, 0), (W, 0, 0), (W, 0, H), (0, 0, H))
    m.quad((W, D, 0), (0, D, 0), (0, D, H), (W, D, H))
    m.quad((0, D, 0), (0, 0, 0), (0, 0, H), (0, D, H))
    m.quad((W, 0, 0), (W, D, 0), (W, D, H), (W, 0, H))
    m.quad((W - t, t, t), (t, t, t), (t, t, H), (W - t, t, H))
    m.quad((t, D - t, t), (W - t, D - t, t), (W - t, D - t, H), (t, D - t, H))
    m.quad((t, t, t), (t, D - t, t), (t, D - t, H), (t, t, H))
    m.quad((W - t, D - t, t), (W - t, t, t), (W - t, t, H), (W - t, D - t, H))
    m.quad((0, D, 0), (W, D, 0), (W, 0, 0), (0, 0, 0))
    m.quad((t, t, t), (W - t, t, t), (W - t, D - t, t), (t, D - t, t))
    m.quad((0, 0, H), (W, 0, H), (W - t, t, H), (t, t, H))
    m.quad((W, D, H), (0, D, H), (t, D - t, H), (W - t, D - t, H))
    m.quad((0, D, H), (0, 0, H), (t, t, H), (t, D - t, H))
    m.quad((W, 0, H), (W, D, H), (W - t, D - t, H), (W - t, t, H))


def cilindro(m, r, H, seg, tubo, t):
    ri = max(0.4, r - t) if tubo else r
    ring_o = [(r * math.cos(2 * math.pi * i / seg), r * math.sin(2 * math.pi * i / seg)) for i in range(seg)]
    ring_i = [(ri * math.cos(2 * math.pi * i / seg), ri * math.sin(2 * math.pi * i / seg)) for i in range(seg)]

    for i in range(seg):
        j = (i + 1) % seg
        a, b = ring_o[i], ring_o[j]
        m.quad((a[0], a[1], 0), (b[0], b[1], 0), (b[0], b[1], H), (a[0], a[1], H))

    if not tubo:
        m.fan((0, 0, 0), [(x, y, 0) for x, y in ring_o], up=False)
        m.fan((0, 0, H), [(x, y, H) for x, y in ring_o], up=True)
        return

    # banda interna del foro, con normali verso il centro
    for i in range(seg):
        j = (i + 1) % seg
        a, b = ring_i[i], ring_i[j]
        m.quad((b[0], b[1], t), (a[0], a[1], t), (a[0], a[1], H), (b[0], b[1], H))
    # fondo del foro (la base piena resta sotto, a quota 0)
    m.fan((0, 0, t), [(x, y, t) for x, y in ring_i], up=True)
    # anello di sopra, tra parete esterna e foro
    for i in range(seg):
        j = (i + 1) % seg
        ao, bo = ring_o[i], ring_o[j]
        ai, bi = ring_i[i], ring_i[j]
        m.quad((ao[0], ao[1], H), (bo[0], bo[1], H), (bi[0], bi[1], H), (ai[0], ai[1], H))
    # sotto pieno
    m.fan((0, 0, 0), [(x, y, 0) for x, y in ring_o], up=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--forma", required=True, choices=["scatola", "cilindro"])
    ap.add_argument("--larghezza", type=float, default=80)
    ap.add_argument("--profondita", type=float, default=60)
    ap.add_argument("--altezza", type=float, default=30)
    ap.add_argument("--diametro", type=float, default=40)
    ap.add_argument("--spessore", type=float, default=2.0)
    ap.add_argument("--cava", action="store_true")
    ap.add_argument("--tubo", action="store_true")
    ap.add_argument("--out", default=os.path.expanduser("~/.jarvis/stl"))
    a = ap.parse_args()

    if min(a.larghezza, a.profondita, a.altezza, a.diametro) < 2:
        print("Misure troppo piccole: il minimo e' 2 mm.", file=sys.stderr)
        return 2
    if a.spessore < 0.8:
        print("Lo spessore minimo sensato e' 0.8 mm.", file=sys.stderr)
        return 2

    os.makedirs(a.out, exist_ok=True)
    m = Mesh()
    if a.forma == "scatola":
        if a.spessore * 2 >= min(a.larghezza, a.profondita):
            print("Pareti troppo spesse per quelle misure.", file=sys.stderr)
            return 2
        scatola(m, a.larghezza, a.profondita, a.altezza, a.spessore, a.cava)
        nome = "scatola_%gx%gx%g%s.stl" % (a.larghezza, a.profondita, a.altezza, "_cava" if a.cava else "")
    else:
        r = a.diametro / 2
        if a.tubo and a.spessore >= r:
            print("Il tubo ha pareti piu spesse del raggio.", file=sys.stderr)
            return 2
        cilindro(m, r, a.altezza, max(24, int(2 * math.pi * r / 1.5)), a.tubo, a.spessore)
        nome = "cilindro_d%gx%g%s.stl" % (a.diametro, a.altezza, "_tubo" if a.tubo else "")

    path = os.path.join(a.out, nome)
    n = m.write(path)
    print("%s\n%d triangoli" % (path, n))
    return 0


if __name__ == "__main__":
    sys.exit(main())
